

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Listado Puntuaciones Mensual <a href="<?php echo e(URL::to('home')); ?>" class="btn btn-secondary"> Atras</a></div>
                <div class="card-body">
                    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
            <h3><b style="color: #FFFFFF">Ranking del Mes</b></h3>
            <br>
            <div class="table-responsive">
                <table  class="table" style="width: 100%;">
                    <thead>
                        <tr>
                            <th style="width: 60%;">
                                <b>
                                    Alias
                                </b>
                            </th>
                            <th style="width: 20%;">
                                <b >
                                    Puntos x Mes
                                </b>
                            </th>
                            <th style="width: 20%;">
                                <b >
                                    Posicion Mes
                                </b>
                            </th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $proveedor_mes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php if($index == 0): ?>
                                    
                                    <?php if($element->id_user == Auth::User()->id ): ?>
                                        <tr>
                                            <td style=" color: #FFFFFF;">
                                                <div style="background: #232E84; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                    <?php echo e($element->alias); ?>

                                                </div>
                                            </td>
                                            <td style=" color: #FFFFFF;">
                                                <div style="background: #232E84; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                    <?php echo e($element->puntuacion); ?>

                                                </div>
                                            </td>
                                            <td style=" color: #FFFFFF;">
                                                <div style="background: #232E84; padding: 10px; margin-top: -15px;">
                                                    <?php echo e($index+1); ?>

                                                </div>
                                            </td>
                                        </tr>
                                        <?php break; ?>
                                    <?php endif; ?>


                                    <tr>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                <?php echo e($element->alias); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                <?php echo e($element->puntuacion); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-top: -15px;">
                                                <?php echo e($index+1); ?>

                                            </div>
                                        </td>
                                    </tr>

                                <?php endif; ?>
                                

                                <?php if($calculo_mes == $index &&  $calculo_second != $calculo_mes && $index != 0): ?>
                                    <tr>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                <?php echo e($element->alias); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                <?php echo e($element->puntuacion); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-top: -15px;">
                                                <?php echo e($index+1); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                
                                <?php if($element->id_user == Auth::User()->id ): ?>
                                    <tr>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #232E84; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                <?php echo e($element->alias); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #232E84; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                <?php echo e($element->puntuacion); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #232E84; padding: 10px; margin-top: -15px;">
                                                <?php echo e($index+1); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
            
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
            <h3><b style="color: #FFFFFF">Ranking Acumulado</b></h3>
            <br>
            <div class="table-responsive">
                <table  class="table" style="width: 100%;">
                    <thead>
                        <tr>
                            <th style="width: 60%;">
                                <b >
                                    Alias
                                </b>
                            </th>
                            <th style="width: 20%;">
                                <b >
                                    Total Acumulado
                                </b>
                            </th>
                            <th style="width: 20%;">
                                <b >
                                    Posicion del General
                                </b>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $proveedor_acumulado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php if($index == 0): ?>
                                    <?php if($element->id_user == Auth::User()->id ): ?>
                                        <tr>
                                            <td style=" color: #FFFFFF;">
                                                <div style="background: #232E84; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                    <?php echo e($element->alias); ?>

                                                </div>
                                            </td>
                                            <td style=" color: #FFFFFF;">
                                                <div style="background: #232E84; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                    <?php echo e($element->puntuacion); ?>

                                                </div>
                                            </td>
                                            <td style=" color: #FFFFFF;">
                                                <div style="background: #232E84; padding: 10px; margin-top: -15px;">
                                                    <?php echo e($index+1); ?>

                                                </div>
                                            </td>
                                        </tr>
                                        <?php break; ?>
                                    <?php endif; ?>
                                    <tr>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                <?php echo e($element->alias); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                <?php echo e($element->puntuacion); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-top: -15px;">
                                                <?php echo e($index+1); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                
                                
                                <?php if($calculo == $index &&  $calculo_acumulado_second != $calculo && $index != 0): ?>
                                    <tr>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                <?php echo e($element->alias); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                <?php echo e($element->puntuacion); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #595959; padding: 10px; margin-top: -15px;">
                                                <?php echo e($index+1); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                
                                <?php if($element->id_user == Auth::User()->id ): ?>
                                    <tr>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #232E84; padding: 10px; margin-right: -25px;margin-top: -15px;">
                                                <?php echo e($element->alias); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #232E84; padding: 10px; margin-right: -25px; margin-top: -15px;">
                                                <?php echo e($element->puntuacion); ?>

                                            </div>
                                        </td>
                                        <td style=" color: #FFFFFF;">
                                            <div style="background: #232E84; padding: 10px; margin-top: -15px;">
                                                <?php echo e($index+1); ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Lesaffre2021-Cat-A\resources\views/backend/listadoPuntuacionesMensual.blade.php ENDPATH**/ ?>