

<?php $__env->startSection('content'); ?>
<!-- Main Wrapper Start -->
<div class="wrapper">
    <!-- Main Content Wrapper Start -->
    <main class="main-content-wrapper">
        <section class="homepage-slider">
            <div class="element-carousel slick-right-bottom" data-slick-options='{
                "slidesToShow": 1, 
                "dots": true
            }'>
                <div class="item" >
                   
                    <div class="single-slide d-flex align-items-center bg-image"
                        data-bg-image="assets/img/slider/splash.png">
                        
                        <div class="container">
                            <h4>Eventos</h4>
                            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-xs-12 col-lg-12" id="bloque">
                                    <b>Fecha del Evento:</b> <?php echo e($evento->start); ?> <br>
                                    <b>Fecha de Cierre:</b> <?php echo e($evento->end); ?> <br>
                                    <b>Evento:</b> <?php echo e($evento->title); ?> <br>
                                    <b>Enlace de conexión:</b> <a href="<?php echo e($evento->enlace); ?>" target="_blank" style="color:#FFFFFF"> <?php echo e($evento->enlace); ?></a>
                                </div>
                            </div>
                            <div style="margin-top: 2%;"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        </section>
    </main>
    <!-- Main Content Wrapper End -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Lesaffre2021-Cat-A\resources\views/frontend/eventos.blade.php ENDPATH**/ ?>